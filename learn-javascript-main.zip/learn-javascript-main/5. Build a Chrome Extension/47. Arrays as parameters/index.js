// Create a function, getFirst(arr), that returns the first item in the array



// Call it with an array as an argument to verify that it works