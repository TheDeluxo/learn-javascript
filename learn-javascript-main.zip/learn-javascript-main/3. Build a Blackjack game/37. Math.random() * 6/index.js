let randomNumber = Math.random()

console.log(randomNumber)


/* 

In which range will our randomNumber be now?

From:
To:

*/