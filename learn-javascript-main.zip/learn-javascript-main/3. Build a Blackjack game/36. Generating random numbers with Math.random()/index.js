let randomNumber = Math.random()

console.log(randomNumber)


/* 

What does Math.random() do?

Your answer: 

*/