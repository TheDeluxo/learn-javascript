let myPoints = 3

// Create two functions, add3Points() and remove1Point(), and have them
// add/remove points to/from the myPoints variable




// Call the functions to that the line below logs out 10
console.log(myPoints)