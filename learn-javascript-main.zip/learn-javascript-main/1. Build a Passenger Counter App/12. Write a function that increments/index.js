let lapsCompleted = 0

// Create a function that increments the lapsCompleted variable with one
// Run it three times




console.log(lapsCompleted)