## Welcome to [Learn JavaScript for Free](https://scrimba.com/learn/learnjavascript?utm_source=scrimba&utm_medium=scrim&utm_campaign=learn_javascript_launch&utm_content=fcc)

Here, you can find the starter files for all the challenges in the course. To get started, download the entire repo and then navigate to the folder you need - the folders are structured just like the course. 

If you have any problems at all, send an email to help@scrimba.com or join our [Discord server](scrimba.com/discord) and we'll give you a hand. 

Happy coding!